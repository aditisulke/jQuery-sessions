// let the calculator display key pressed
const calculator = document.querySelector('.calculator')
const keys = document.querySelector('.calculator-keys')

keys.addEventListener('click', x => {
    if (x.target.matches('button')) {
        console.log("display")
    }
});

//to determine type of key clicked
const key = x.target
const action = key.dataset.action

//to determine action
if (action === 'add' || action === 'subtract' || action === 'multiply' || action === 'divide') {
    console.log('Operator to be implemented')
}
if (!action) { console.log('Digit Entered') }

//to determine of not operator
if (action === 'decimal') { console.log('Decimal key clicked') }
if (action === 'calculate') { console.log('Calculate') }



const display = document.querySelector('.calculator-display')

keys.addEventListener('click', x => {
    if (x.target.matches('button')) {
        const key = e.target
        const action = key.dataset.action
        const keyContent = key.textContent
        const displayedNum = display.textContent
    }
})

//check action
if (!action) {
    if (displayedNum === '0') {
        display.textContent = keyContent
    }
}
if (action === 'decimal') {
    display.textContent = displayedNum + '.'
}


//calculate

if (action === 'add' || action === 'subtract' || action === 'multiply' || action === 'divide') {
    key.classList.add('highlight')
}


//to display new number
keys.addEventListener('click', x => {
    if (x.target.matches('button')) {
        const key = e.target

        // Remove previous number
        if (action === 'add' || action === 'subtract' || action === 'multiply' || action === 'divide') {
          key.classList.add('highlight')
          calculator.dataset.previousKeyType = 'operator'
      }
        Array.from(key.parentNode.children)
            .forEach(k => k.classList.remove('highlight'))
    }
})


const previousKeyType = calculator.dataset.previousKeyType

if (!action) {
  if (displayedNum === '0' || previousKeyType === 'operator') {
    display.textContent = keyContent
  } else {
    display.textContent = displayedNum + keyContent
  }
}

//display  number
if (action === 'add' || action === 'subtract' || action === 'multiply' || action === 'divide') {
    calculator.dataset.firstValue = displayedNum
    calculator.dataset.operator = action
}

if (action === 'calculate') {
    const secondValue = displayedNum
    const firstValue = calculator.dataset.firstValue
    const operator = calculator.dataset.operator
    const secondValue = displayedNum
    
    display.textContent = calculate(firstValue, operator, secondValue)
  }


  const calculate = (n1, operator, n2) => {
      let result = ' '
      
      if (operator === 'add') {
        result = n1 + n2
      } else if (operator === 'subtract') {
        result = n1 - n2
      } else if (operator === 'multiply') {
        result = n1 * n2
      } else if (operator === 'divide') {
        result = n1 / n2
      }
      
    return calculate;
  }
