var i=1;
//to print 1-10,10-20......90=-100
for (var i=0;i<=100;i++){
    //total+=i;
    if(i%10===0){
        document.writeln(i +" "+ "<br>");
    }
    else{
        document.write(" "+i+" ");
    }
    
}

//document.write(total);