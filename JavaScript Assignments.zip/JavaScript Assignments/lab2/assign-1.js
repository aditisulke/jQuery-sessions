let total=0;
//to print 1-10,10-20......90=-100
for (var i=0;i<=100;i++){
    //total+=i;
    
    document.write(i);
}

//document.write(total);