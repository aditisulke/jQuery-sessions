var p=100;
var r=10;
var n=4;
var totalInterest;

document.write('Enter Principle amount: '+p);
document.write('Enter Rate of interest: '+r);
document.write('Enter Period in Years: '+n);

totalInterest=(p*(1+(r/100))**n)-p;

document.write('Total: '+totalInterest);