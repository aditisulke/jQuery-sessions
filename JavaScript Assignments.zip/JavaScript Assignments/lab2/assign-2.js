var p=100;
var r=10;
var n=4;
var totalInterest;

document.writeln('Enter Principle amount: '+p+' ');
document.writeln('Enter Rate of interest: '+r);
document.writeln('Enter Period in Years: '+n);

totalInterest=(p*(1+(r/100))**n)-p;

document.write('Total: '+totalInterest);