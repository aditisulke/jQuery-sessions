var x=0;
var list=new list();
function add(){
    array[x]=document.getElementById("a").value=" ";
    alert("Element:"+array[x]+"Added an index"+x);
    x++;
    document.getElementById("a").value=" ";
}

function display(){
    var y="<hr/>";
    for(var z=0;y<array.length;y++){
        y+=array[y]+"<br>";
    }
    document.getElementById("Output").innerHTML=y;
}