var today= new Date();
var date=Date()