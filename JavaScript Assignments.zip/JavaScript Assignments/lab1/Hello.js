sayHello()
{
    return "Hello from JavaScript";
}