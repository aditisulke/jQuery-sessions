document.getElementById('href').innerHTML=location.href;
document.getElementById('path').innerHTML=location.pathname;
document.getElementById('protocol').innerHTML=location.protocol;

function goback(){
    window.history.back();
}