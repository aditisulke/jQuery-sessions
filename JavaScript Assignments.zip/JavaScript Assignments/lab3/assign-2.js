var companyName="Cybage Software Pvt Ltd";
var searchCh=prompt("Enter alphabet to be searched :");

if(companyName.match(searchCh))
{
    var index=companyName.indexOf(searchCh);
    document.writeln('Character '+searchCh+' is found at index '+index+"<br>")
}
else{
    document.writeln('Character '+searchCh+' not found');
}
document.writeln(companyName+' is popularly known as Cybage Softwares <br>');
document.writeln(companyName.toLowerCase()+'<br>');
document.writeln(companyName.toUpperCase()+'<br>');