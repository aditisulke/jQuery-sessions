var today=new Date();
var date= Date();
var hour=today.getHours();
var minute=today.getMinutes();
var second=today.getSeconds();

document.writeln(date+'<br>');
if(hour<12){
    document.writeln("Good Morning <br>");
}
else if(hour<=17 && second<=1){
    document.writeln("Good Afternoon <br>")
}
else{
    document.writeln("Good Night <br>")
}