$('document').ready(()=>{
$('button').click(()=>{
    $('div#animate').fadeToggle(1000)
  //  $('div#animate').slideDown(1000)
})
   
})