$('document').ready(()=>{

    $('.pics').cycle({ 
        fx:     'shuffle', 
        easing: 'easeOutBack', 
        delay:  -4000 
    });

});
