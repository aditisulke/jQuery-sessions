$('document').ready(()=>{
    // $('button').click(()=>{
    //     $('p')
    //     .animate({width: "100%"})
    //     .animate({fontSize: "40px"})
    //     .animate({borderWidth:"20px"})
    // })

    $('button').click(()=>{
    $('p').toggle();})
})