$('document').ready(
    ()=>{
       $('button').click(()=>{
           alert("Button clicked!!!")
       }); 
    }
)