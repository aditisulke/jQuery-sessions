//Horizontal Flip///
// $(function(){
//     $(".flip").flip({
//         trigger: 'hover'
//     });
// });

//Vertical Flip///
$(function(){
    $(".flip").flip({
        trigger: 'hover',
        axis: 'x'
    });
});