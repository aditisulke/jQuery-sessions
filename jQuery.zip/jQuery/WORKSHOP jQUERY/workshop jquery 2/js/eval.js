$(document).ready(function() {
    $('#check').click(function() {
      if ($('#test-input').attr('type') == 'text') {
        $('#test-input').attr('type', 'password');
      } else {
        $('#test-input').attr('type', 'text');
      }
    });
  });





// $(".toggle-password").click(function() {

//     $(this).toggleClass("fa-eye fa-eye-slash");
//     var input = $($(this).attr("toggle"));
//     if (input.attr("type") == "password") {
//       input.attr("type", "text");
//     } else {
//       input.attr("type", "password");
//     }
//   });