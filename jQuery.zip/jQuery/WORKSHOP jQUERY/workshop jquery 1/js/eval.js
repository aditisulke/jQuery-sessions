$(document).ready(function(){
    $("#add").on("keyup", function() {
      let r = $(this).val().toLowerCase();
      $("#tab tr").filter(function() {
        $(this).toggle($(this).text().toLowerCase().indexOf(r) > -1)
      });
    });
  });


  