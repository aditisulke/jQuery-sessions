$(document).ready(function(){

    $("toggle").change(function(){
        if($(this).is(':checked')){
            $("password").attr("type","text");
            $("toggleText").text("Hide");
        }
        else{
            $("password").attr("type","password");
            $("toggleText").text("Show");
        }
    });
  });