function setupSomeGlobals(){
    var num=666;


    //store the reference to function as global variables
    gAlertNumber=function(){
    alert(num);}

    gIncreaseNumber=function(){
        n++;
    }

    gSetNumber=function(x){
        num=x;
    }
}

setupSomeGlobals()//value of num=666
gAlertNumber()// alerts 666
gIncreaseNumber()

gAlertNumber()//alerts 667
gSetNumber(600)
gAlertNumber()//alerts 600