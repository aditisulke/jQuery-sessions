var Module=(function(){
    var x=89;
    function privateMethod(){
        document.write('inside private method');
    }

    return{
        publicMethod:function(){
            privateMethod();
            console.log(x);
        }
    };
}) ();
Module.publicMethod()