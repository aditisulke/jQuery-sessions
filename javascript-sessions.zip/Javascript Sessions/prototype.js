function Cat(name,color){
    this.name=name
    this.color=color
}
Cat.prototype.age=3;
var muffin=new Cat("muffin","white");
var cuffin=new Cat("cuffin","grey");


Cat.prototype={age:2};

var snow=new Cat("snow","grey")
console.log(muffin.age);
