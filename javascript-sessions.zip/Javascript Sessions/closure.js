function sayHello(lang){
    var text='Talk'+lang;
    var sayAlert=function(fluency){
        if(fluency===1){
            document.writeln("Beginner"+text);
        }
        else{
            document.write("Expert"+text);
        }
    }
    return sayAlert;
}

var talkHindi=sayHello("Hindi");
talkHindi(1);
//talkHindi(2);
talkHindi(4);

var talkMarathi=sayHello("Marathi");
talkMarathi(1);

var talkEng=sayHello("English");
talkEng(2);
