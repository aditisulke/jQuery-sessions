var fruits = ['guava', 'watermelon', 'papaya', 'kiwi']
console.log(fruits.last)
Object.defineProperty(Array.prototype, 'last'{
    get: function () {
        return this[this.length - 1];
}});

document.write(fruit.last);
document.write(arr.last);
