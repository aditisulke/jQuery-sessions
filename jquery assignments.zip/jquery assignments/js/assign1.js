$(document).ready(function() {
    $.getJSON("https://jsonplaceholder.typicode.com/photos", function(data){
        var containerElement=document.getElementById('datashow');
        var str=' ';

        data.forEach(element=>{
            var images=element.thumbnailUrl+'.jpeg';
            var divStr='<div class="person" style="align:centre;">'+
            "<image src="+img +"width='70 height='100'>"+"</br>"+
            '<p>'+element.id+'<p><br>'+
            '<p>'+element.title+'<p>'
            '</div>';
            str=str+divStr;
        });
        containerElement.innerHTML=str;
    });
});