var value=89;

function myData(){
   var value;
    console.log(value);
}



console.log(value);//89

myData();