function accept() {
alert('asd')
var values=document.querySelectorAll('input');
values.forEach((i,v,a)=>{name=i.value;});
console.log(name);

}