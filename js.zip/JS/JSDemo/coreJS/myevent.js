function clicked(){
    alert('Clicked on the button');
}